class AppRoutes {
  static const String splash = '/';
  static const String walkthrough = '/walkthrough';
  static const String login = '/login';
  static const String emailLogin = '/email-login';
  static const String signup = '/signup';
  static const privacyPolicy = '/privacy-policy';

  static const String dashboard = '/dashboard';
  static const String riwayat = '/riwayat';
  static const String pembayaran = '/pembayaran';
  static const String profile = '/profile';

  static const articleList = '/article-list';
  static const articleDetail = '/article-detail';

  static const String notifikasi = '/notifikasi';
  static const String sertifikat = '/sertifikat';
  static const String listKebun = '/list-kebun';
  static const hitungPohon = '/hitung-pohon';
  static const hitungPohonHistory = '/hitung-pohon/history';
  static const hitungPohonResult = '/hitung-pohon/result';

  static const String ehara = '/ehara';
  static const String eharaFullMap = '/ehara-full-map';
  static const String rekomendasiPemupukan = '/rekomendasi-pemupukan';
  static const String ganoderma = '/ganoderma';
  static const String ganodermaFullMap = '/ganoderma-full-map';

  static const String form1 = '/form1';
  static const String form2 = '/form2';
  static const String form3 = '/form3';
  static const String form3Map = '/form3-map';

  static const String detailProfil = '/detail-profil';
  static const String changePassword = '/change-password';
  static const String notifikasiSettings = '/notifikasi-settings';
  static const String aboutApp = '/about-app';
  static const String termsPlaceholder = '/terms-placeholder';
  static const String privacyPlaceholder = '/privacy-placeholder';

  static const String detailRiwayat = '/riwayat/detail';
}
