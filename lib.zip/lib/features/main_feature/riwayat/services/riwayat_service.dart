import '../models/riwayat_model.dart';

class RiwayatService {
  Future<List<RiwayatModel>> getRiwayatList() async {
    await Future.delayed(const Duration(milliseconds: 350));

    return [
      RiwayatModel(
        projectName: 'Projek Nusantara',
        date: DateTime(2026, 3, 9),
        farmName: 'Kwala Sawit',
      ),
      RiwayatModel(
        projectName: 'Projek Nusantara',
        date: DateTime(2026, 3, 8),
        farmName: 'Kwala Sawit',
      ),
      RiwayatModel(
        projectName: 'Projek Nusantara',
        date: DateTime(2026, 3, 7),
        farmName: 'Kwala Sawit',
      ),
    ];
  }
}