import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/utils/responsive.dart';
import '../../../../../core/widgets/responsive_list_page_shell.dart';
import '../../../../../core/widgets/responsive_page_header.dart';
import '../../models/riwayat_model.dart';
import '../widgets/riwayat_card.dart';

class RiwayatPage extends StatelessWidget {
  const RiwayatPage({super.key});

  List<RiwayatModel> _dummyRiwayat() {
    return [
      RiwayatModel(
        projectName: 'Projek Analisis Hara A',
        farmName: 'Kebun Sei Rampah',
        date: DateTime(2026, 4, 12),
      ),
      RiwayatModel(
        projectName: 'Projek Analisis Hara B',
        farmName: 'Kebun Medan Timur',
        date: DateTime(2026, 4, 10),
      ),
      RiwayatModel(
        projectName: 'Projek Analisis Hara C',
        farmName: 'Kebun Deli Serdang',
        date: DateTime(2026, 4, 8),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final items = _dummyRiwayat();

    return ResponsiveListPageShell(
      header: ResponsivePageHeader(
        title: 'Riwayat',
        onBackTap: () => context.pop(),
      ),
      child: items.isEmpty
          ? Center(
        child: Text(
          'Belum ada riwayat',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: Responsive.sp(context, 14),
            color: const Color(0xFF555555),
            fontWeight: FontWeight.w600,
          ),
        ),
      )
          : ListView.separated(
        physics: const BouncingScrollPhysics(),
        itemCount: items.length,
        separatorBuilder: (_, __) =>
            SizedBox(height: Responsive.h(context, 14)),
        itemBuilder: (context, index) {
          final item = items[index];

          return RiwayatCard(
            riwayat: item,
            calendarIconPath: 'assets/icons/calendar.png',
            kebunIconPath: 'assets/icons/kebun.png',
            onTapDetail: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Detail riwayat placeholder'),
                ),
              );
            },
          );
        },
      ),
    );
  }
}