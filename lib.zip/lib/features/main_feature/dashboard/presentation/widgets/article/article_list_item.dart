import 'package:flutter/material.dart';
import '../../../../../../core/constants/app_colors.dart';
import '../../../../../../core/theme/app_text_styles.dart';
import '../../../../../../core/utils/responsive.dart';
import '../../../models/article_model.dart';

class ArticleListItem extends StatelessWidget {
  final ArticleModel article;
  final VoidCallback onTapReadMore;

  const ArticleListItem({
    super.key,
    required this.article,
    required this.onTapReadMore,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(
            Responsive.r(context, 12),
          ),
          child: AspectRatio(
            aspectRatio: Responsive.isCompact(context) ? 16 / 8.5 : 16 / 7.3,
            child: Image.asset(
              article.imagePath,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
        ),
        SizedBox(height: Responsive.h(context, 14)),
        Padding(
          padding: EdgeInsets.symmetric(
            horizontal: Responsive.w(context, 4),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                article.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: AppTextStyles.semiBold(
                  fontSize: Responsive.sp(context, 12),
                  color: AppColors.textPrimary,
                ),
              ),
              SizedBox(height: Responsive.h(context, 8)),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      article.date,
                      style: AppTextStyles.bodySmall(
                        color: AppColors.textPrimary.withOpacity(0.45),
                      ).copyWith(
                        fontSize: Responsive.sp(context, 10),
                      ),
                    ),
                  ),
                  SizedBox(width: Responsive.w(context, 12)),
                  Flexible(
                    child: InkWell(
                      onTap: onTapReadMore,
                      child: Text(
                        'Baca Artikel Selengkapnya ->',
                        textAlign: TextAlign.right,
                        style: AppTextStyles.medium(
                          fontSize: Responsive.sp(context, 12.5),
                          color: AppColors.accent,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}