import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/utils/responsive.dart';
import '../../../../../core/widgets/responsive_list_page_shell.dart';
import '../../../../../core/widgets/responsive_page_header.dart';
import '../../models/sertifikat_model.dart';
import '../widgets/sertifikat_card.dart';

class SertifikatPage extends StatelessWidget {
  const SertifikatPage({super.key});

  List<SertifikatModel> _dummySertifikat() {
    return [
      SertifikatModel(
        projectName: 'Projek Analisis Hara A',
        farmName: 'Kebun Sei Rampah',
        date: DateTime(2026, 4, 12),
        eHaraCertificateNumber: 'EH-2026-0001',
        ganomonCertificateNumber: 'GN-2026-0001',
        isPublished: true,
      ),
      SertifikatModel(
        projectName: 'Projek Analisis Hara B',
        farmName: 'Kebun Medan Timur',
        date: DateTime(2026, 4, 10),
        eHaraCertificateNumber: 'EH-2026-0002',
        ganomonCertificateNumber: 'GN-2026-0002',
        isPublished: false,
      ),
      SertifikatModel(
        projectName: 'Projek Analisis Hara C',
        farmName: 'Kebun Deli Serdang',
        date: DateTime(2026, 4, 8),
        eHaraCertificateNumber: 'EH-2026-0003',
        ganomonCertificateNumber: 'GN-2026-0003',
        isPublished: true,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final items = _dummySertifikat();

    return ResponsiveListPageShell(
      header: ResponsivePageHeader(
        title: 'Sertifikat',
        onBackTap: () => context.pop(),
      ),
      child: items.isEmpty
          ? Center(
        child: Text(
          'Belum ada sertifikat',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: Responsive.sp(context, 14),
            color: const Color(0xFF555555),
            fontWeight: FontWeight.w600,
          ),
        ),
      )
          : ListView.separated(
        physics: const BouncingScrollPhysics(),
        itemCount: items.length,
        separatorBuilder: (_, __) =>
            SizedBox(height: Responsive.h(context, 14)),
        itemBuilder: (context, index) {
          final item = items[index];

          return SertifikatCard(
            sertifikat: item,
            calendarIconPath: 'assets/icons/calendar.png',
            kebunIconPath: 'assets/icons/kebun.png',
            sertifikatIconPath: 'assets/icons/sertifikat.png',
            onDownload: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    item.isPublished
                        ? 'Download sertifikat placeholder'
                        : 'Sertifikat belum tersedia',
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}