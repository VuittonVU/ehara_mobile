import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../../core/utils/responsive.dart';
import '../../../../../core/widgets/responsive_list_page_shell.dart';
import '../../../../../core/widgets/responsive_page_header.dart';
import '../../models/pembayaran_model.dart';
import '../widgets/pembayaran_card.dart';
import '../widgets/pembayaran_empty_state.dart';

class PembayaranPage extends StatelessWidget {
  const PembayaranPage({super.key});

  List<PembayaranModel> _dummyPembayaran() {
    return [
      PembayaranModel(
        id: '1',
        namaProjek: 'Projek Analisis Hara A',
        tanggal: DateTime(2026, 4, 12),
        jumlahBaris: 12,
        status: PembayaranStatus.proses,
        kebun: 'Kebun Sei Rampah',
        lokasi: 'Sumatera Utara',
        hargaPerSatuanPohon: 1500,
        totalPohon: 240,
        perkiraanLuasHa: 2.4,
        subTotal: 360000,
        orderId: 'ORD-2026-0001',
      ),
      PembayaranModel(
        id: '2',
        namaProjek: 'Projek Analisis Hara B',
        tanggal: DateTime(2026, 4, 10),
        jumlahBaris: 8,
        status: PembayaranStatus.selesai,
        kebun: 'Kebun Medan Timur',
        lokasi: 'Medan',
        hargaPerSatuanPohon: 1700,
        totalPohon: 180,
        perkiraanLuasHa: 1.8,
        subTotal: 306000,
        orderId: 'ORD-2026-0002',
      ),
      PembayaranModel(
        id: '3',
        namaProjek: 'Projek Analisis Hara C',
        tanggal: DateTime(2026, 4, 8),
        jumlahBaris: 15,
        status: PembayaranStatus.dibatalkan,
        kebun: 'Kebun Deli Serdang',
        lokasi: 'Deli Serdang',
        hargaPerSatuanPohon: 1600,
        totalPohon: 300,
        perkiraanLuasHa: 3.0,
        subTotal: 480000,
        orderId: 'ORD-2026-0003',
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final items = _dummyPembayaran();

    return ResponsiveListPageShell(
      header: ResponsivePageHeader(
        title: 'Pembayaran',
        onBackTap: () => context.pop(),
      ),
      child: items.isEmpty
          ? const PembayaranEmptyState(
        title: 'Belum ada pembayaran',
        description: 'Data pembayaran akan muncul di sini.',
      )
          : ListView.separated(
        physics: const BouncingScrollPhysics(),
        itemCount: items.length,
        separatorBuilder: (_, __) =>
            SizedBox(height: Responsive.h(context, 14)),
        itemBuilder: (context, index) {
          final item = items[index];
          final tanggalText =
          DateFormat('dd-MM-yyyy').format(item.tanggal);

          return PembayaranCard(
            item: item,
            tanggalText: tanggalText,
            calendarIconPath: 'assets/icons/calendar.png',
            kebunIconPath: 'assets/icons/kebun.png',
            statusIconPath: 'assets/icons/status.png',
            onPrimaryTap: () {
              String message;

              switch (item.status) {
                case PembayaranStatus.proses:
                  message = 'Menu proses pembayaran placeholder';
                  break;
                case PembayaranStatus.dibatalkan:
                  message = 'Menu pembayaran placeholder';
                  break;
                case PembayaranStatus.selesai:
                  message = 'Download invoice placeholder';
                  break;
              }

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(message),
                ),
              );
            },
          );
        },
      ),
    );
  }
}