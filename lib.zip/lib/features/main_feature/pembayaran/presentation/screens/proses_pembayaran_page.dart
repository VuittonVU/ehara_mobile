import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/utils/responsive.dart';
import '../../../../../core/widgets/responsive_list_page_shell.dart';
import '../../../../../core/widgets/responsive_page_header.dart';

class ProsesPembayaranPage extends StatelessWidget {
  const ProsesPembayaranPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ResponsiveListPageShell(
      header: ResponsivePageHeader(
        title: 'Proses Pembayaran',
        onBackTap: () => context.pop(),
      ),
      child: Column(
        children: [
          SizedBox(height: Responsive.h(context, 20)),
          Icon(
            Icons.qr_code_2,
            size: Responsive.w(context, 200),
          ),
          SizedBox(height: Responsive.h(context, 20)),
          Text(
            'Scan QR untuk pembayaran',
            style: TextStyle(
              fontSize: Responsive.sp(context, 16),
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: Responsive.h(context, 20)),
          SizedBox(
            width: double.infinity,
            height: Responsive.h(context, 50),
            child: ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Simulasi bayar berhasil'),
                  ),
                );
              },
              child: const Text('Saya Sudah Bayar'),
            ),
          ),
        ],
      ),
    );
  }
}