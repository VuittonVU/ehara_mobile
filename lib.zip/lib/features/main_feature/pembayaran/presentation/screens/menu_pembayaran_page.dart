import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/utils/responsive.dart';
import '../../../../../core/widgets/responsive_list_page_shell.dart';
import '../../../../../core/widgets/responsive_page_header.dart';

class MenuPembayaranPage extends StatelessWidget {
  const MenuPembayaranPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ResponsiveListPageShell(
      header: ResponsivePageHeader(
        title: 'Menu Pembayaran',
        onBackTap: () => context.pop(),
      ),
      child: Column(
        children: [
          _buildPaymentButton(context, 'QRIS'),
          SizedBox(height: Responsive.h(context, 12)),
          _buildPaymentButton(context, 'Bank Transfer'),
          SizedBox(height: Responsive.h(context, 12)),
          _buildPaymentButton(context, 'E-Wallet'),
        ],
      ),
    );
  }

  Widget _buildPaymentButton(BuildContext context, String title) {
    return SizedBox(
      width: double.infinity,
      height: Responsive.h(context, 50),
      child: ElevatedButton(
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Pilih $title')),
          );
        },
        child: Text(title),
      ),
    );
  }
}