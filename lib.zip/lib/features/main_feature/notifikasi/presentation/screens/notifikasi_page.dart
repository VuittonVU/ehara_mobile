import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/utils/responsive.dart';
import '../../../../../core/widgets/responsive_list_page_shell.dart';
import '../../../../../core/widgets/responsive_page_header.dart';

class NotifikasiPage extends StatelessWidget {
  const NotifikasiPage({super.key});

  List<_DummyNotification> _dummyNotifications() {
    return const [
      _DummyNotification(
        title: 'Pembayaran berhasil',
        message: 'Pembayaran untuk Projek Analisis Hara A telah berhasil.',
      ),
      _DummyNotification(
        title: 'Sertifikat tersedia',
        message: 'Sertifikat untuk Projek Analisis Hara B sudah dapat diunduh.',
      ),
      _DummyNotification(
        title: 'Analisis selesai',
        message: 'Hasil analisis untuk Kebun Deli Serdang telah selesai diproses.',
      ),
      _DummyNotification(
        title: 'Pengingat',
        message: 'Silakan lengkapi data analisis yang masih belum selesai.',
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final items = _dummyNotifications();

    return ResponsiveListPageShell(
      header: ResponsivePageHeader(
        title: 'Notifikasi',
        onBackTap: () => context.pop(),
      ),
      child: items.isEmpty
          ? Center(
        child: Text(
          'Belum ada notifikasi',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: Responsive.sp(context, 14),
            color: const Color(0xFF555555),
            fontWeight: FontWeight.w600,
          ),
        ),
      )
          : ListView.separated(
        physics: const BouncingScrollPhysics(),
        itemCount: items.length,
        separatorBuilder: (_, __) =>
            SizedBox(height: Responsive.h(context, 12)),
        itemBuilder: (context, index) {
          final notif = items[index];

          return Container(
            padding: EdgeInsets.all(
              Responsive.w(context, 14),
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(
                Responsive.r(context, 16),
              ),
              border: Border.all(
                color: const Color(0xFFE2E2E2),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: Responsive.w(context, 6),
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: Responsive.w(context, 40),
                  height: Responsive.w(context, 40),
                  decoration: const BoxDecoration(
                    color: Color(0xFFEAF5F0),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.notifications_none_rounded,
                    size: Responsive.w(context, 22),
                    color: const Color(0xFF2F7D69),
                  ),
                ),
                SizedBox(width: Responsive.w(context, 12)),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        notif.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: Responsive.sp(context, 14),
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFF333333),
                        ),
                      ),
                      SizedBox(height: Responsive.h(context, 4)),
                      Text(
                        notif.message,
                        style: TextStyle(
                          fontSize: Responsive.sp(context, 12.5),
                          height: 1.35,
                          color: const Color(0xFF666666),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _DummyNotification {
  final String title;
  final String message;

  const _DummyNotification({
    required this.title,
    required this.message,
  });
}