import 'package:flutter/material.dart';
import '../utils/responsive.dart';

class ResponsivePageHeader extends StatelessWidget {
  final String title;
  final VoidCallback? onBackTap;
  final Widget? trailing;

  const ResponsivePageHeader({
    super.key,
    required this.title,
    this.onBackTap,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final sideSize = Responsive.w(context, 42);

    return Padding(
      padding: EdgeInsets.fromLTRB(
        Responsive.w(context, 18),
        Responsive.h(context, 14),
        Responsive.w(context, 18),
        Responsive.h(context, 8),
      ),
      child: Row(
        children: [
          SizedBox(
            width: sideSize,
            height: sideSize,
            child: onBackTap == null
                ? const SizedBox.shrink()
                : Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: onBackTap,
                borderRadius: BorderRadius.circular(
                  Responsive.r(context, 99),
                ),
                child: Center(
                  child: Icon(
                    Icons.arrow_back,
                    size: Responsive.w(context, 24),
                    color: const Color(0xFF2F2F2F),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: Text(
              title,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: Responsive.sp(context, 22),
                fontWeight: FontWeight.w800,
                color: const Color(0xFF333333),
                height: 1.05,
              ),
            ),
          ),
          SizedBox(
            width: sideSize,
            height: sideSize,
            child: trailing ?? const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}