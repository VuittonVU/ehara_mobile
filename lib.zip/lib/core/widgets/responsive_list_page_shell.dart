import 'package:flutter/material.dart';
import '../utils/responsive.dart';
import 'app_background.dart';

class ResponsiveListPageShell extends StatelessWidget {
  final Widget header;
  final Widget child;
  final EdgeInsetsGeometry? contentPadding;

  const ResponsiveListPageShell({
    super.key,
    required this.header,
    required this.child,
    this.contentPadding,
  });

  @override
  Widget build(BuildContext context) {
    final bottomSafeArea = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: Column(
            children: [
              header,
              Expanded(
                child: Padding(
                  padding: contentPadding ??
                      EdgeInsets.fromLTRB(
                        Responsive.w(context, 18),
                        Responsive.h(context, 12),
                        Responsive.w(context, 18),
                        Responsive.h(context, 14) + bottomSafeArea,
                      ),
                  child: child,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}