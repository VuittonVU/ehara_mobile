import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../constants/app_colors.dart';
import '../theme/app_text_styles.dart';
import '../utils/responsive.dart';

class AppBottomNavbar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const AppBottomNavbar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).padding.bottom;
    final isCompact = Responsive.isCompact(context);

    final fabSize = Responsive.w(context, isCompact ? 68 : 74);
    final fabLabelHeight = Responsive.h(context, 28);
    final fabLift = Responsive.h(context, isCompact ? 20 : 26);

    final itemHeight = Responsive.h(context, isCompact ? 58 : 62);
    final topPadding = Responsive.h(context, 8);
    final bottomPadding = bottomInset > 0
        ? math.max(8, bottomInset - 2).toDouble()
        : Responsive.h(context, 10);

    final barHeight = itemHeight + topPadding + bottomPadding;
    final totalHeight = barHeight + fabLift;

    return SizedBox(
      height: totalHeight,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.bottomCenter,
        children: [
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              height: barHeight,
              padding: EdgeInsets.only(
                left: Responsive.w(context, 8),
                right: Responsive.w(context, 8),
                top: topPadding,
                bottom: bottomPadding,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  top: BorderSide(
                    color: AppColors.textPrimary.withOpacity(0.14),
                  ),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: Responsive.w(context, 10),
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: _BottomNavItem(
                      iconPath: 'assets/icons/house.png',
                      label: 'Dashboard',
                      isActive: currentIndex == 0,
                      onTap: () => onTap(0),
                    ),
                  ),
                  Expanded(
                    child: _BottomNavItem(
                      iconPath: 'assets/icons/riwayat.png',
                      label: 'Riwayat',
                      isActive: currentIndex == 1,
                      onTap: () => onTap(1),
                    ),
                  ),
                  SizedBox(width: fabSize + Responsive.w(context, 18)),
                  Expanded(
                    child: _BottomNavItem(
                      iconPath: 'assets/icons/cart.png',
                      label: 'Pembayaran',
                      isActive: currentIndex == 3,
                      onTap: () => onTap(3),
                    ),
                  ),
                  Expanded(
                    child: _BottomNavItem(
                      iconPath: 'assets/icons/circle_user.png',
                      label: 'Profil',
                      isActive: currentIndex == 4,
                      onTap: () => onTap(4),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: barHeight - (fabSize * 0.58),
            child: _CenterNavButton(
              isActive: currentIndex == 2,
              size: fabSize,
              labelHeight: fabLabelHeight,
              onTap: () => onTap(2),
            ),
          ),
        ],
      ),
    );
  }
}

class _BottomNavItem extends StatefulWidget {
  final String iconPath;
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _BottomNavItem({
    required this.iconPath,
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  State<_BottomNavItem> createState() => _BottomNavItemState();
}

class _BottomNavItemState extends State<_BottomNavItem> {
  bool _isPressed = false;

  void _setPressed(bool value) {
    if (_isPressed == value) return;
    setState(() {
      _isPressed = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    final itemColor =
    widget.isActive ? const Color(0xFF387867) : AppColors.textPrimary;

    return AnimatedScale(
      scale: _isPressed ? 0.97 : 1,
      duration: const Duration(milliseconds: 110),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            HapticFeedback.lightImpact();
            widget.onTap();
          },
          onTapDown: (_) => _setPressed(true),
          onTapUp: (_) => _setPressed(false),
          onTapCancel: () => _setPressed(false),
          borderRadius: BorderRadius.circular(
            Responsive.r(context, 12),
          ),
          child: SizedBox(
            height: Responsive.h(context, 62),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Image.asset(
                  widget.iconPath,
                  width: Responsive.w(context, 22),
                  height: Responsive.w(context, 22),
                  color: itemColor,
                ),
                SizedBox(height: Responsive.h(context, 4)),
                SizedBox(
                  height: Responsive.h(context, 30),
                  child: Center(
                    child: Text(
                      widget.label,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: AppTextStyles.caption(
                        color: itemColor,
                      ).copyWith(
                        fontSize: Responsive.sp(context, Responsive.isCompact(context) ? 10 : 11.5),
                        height: 1.1,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CenterNavButton extends StatefulWidget {
  final bool isActive;
  final double size;
  final double labelHeight;
  final VoidCallback onTap;

  const _CenterNavButton({
    required this.isActive,
    required this.size,
    required this.labelHeight,
    required this.onTap,
  });

  @override
  State<_CenterNavButton> createState() => _CenterNavButtonState();
}

class _CenterNavButtonState extends State<_CenterNavButton> {
  bool _isPressed = false;

  void _setPressed(bool value) {
    if (_isPressed == value) return;
    setState(() {
      _isPressed = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    final textColor =
    widget.isActive ? const Color(0xFF387867) : AppColors.textPrimary;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {
          HapticFeedback.mediumImpact();
          widget.onTap();
        },
        onTapDown: (_) => _setPressed(true),
        onTapUp: (_) => _setPressed(false),
        onTapCancel: () => _setPressed(false),
        borderRadius: BorderRadius.circular(widget.size / 2),
        child: AnimatedScale(
          scale: _isPressed ? 0.95 : 1,
          duration: const Duration(milliseconds: 100),
          child: SizedBox(
            width: widget.size + Responsive.w(context, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: widget.size,
                  height: widget.size,
                  decoration: BoxDecoration(
                    color: const Color(0xFF00B300),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.14),
                        blurRadius: Responsive.w(context, 12),
                        offset: const Offset(0, 4),
                      ),
                    ],
                    border: widget.isActive
                        ? Border.all(
                      color: const Color(0xFFE5F3EC),
                      width: Responsive.w(context, 3),
                    )
                        : null,
                  ),
                  child: Center(
                    child: Image.asset(
                      'assets/icons/palm.png',
                      width: widget.size * 0.38,
                      height: widget.size * 0.38,
                      color: Colors.white,
                    ),
                  ),
                ),
                SizedBox(height: Responsive.h(context, 6)),
                SizedBox(
                  height: widget.labelHeight,
                  child: Center(
                    child: Text(
                      'Tambah\nAnalisis',
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: AppTextStyles.caption(
                        color: textColor,
                      ).copyWith(
                        fontSize: Responsive.sp(context, 10.5),
                        height: 1.08,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}